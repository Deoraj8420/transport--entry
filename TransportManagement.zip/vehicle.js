document.getElementById('vehicleForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const vehicle = {
    number: document.getElementById('vehicle_no').value,
    model: document.getElementById('model').value,
    rc_date: document.getElementById('rc_date').value,
    insurance_expiry: document.getElementById('insurance_expiry').value,
  };
  const vehicles = JSON.parse(localStorage.getItem('vehicles') || '[]');
  vehicles.push(vehicle);
  localStorage.setItem('vehicles', JSON.stringify(vehicles));
  renderVehicles();
});

function renderVehicles() {
  const list = document.getElementById('vehicleList');
  const vehicles = JSON.parse(localStorage.getItem('vehicles') || '[]');
  list.innerHTML = '';
  vehicles.forEach((v, i) => {
    const li = document.createElement('li');
    li.textContent = v.number + ' - ' + v.model + ' (RC: ' + v.rc_date + ')';
    list.appendChild(li);
  });
}

renderVehicles();
